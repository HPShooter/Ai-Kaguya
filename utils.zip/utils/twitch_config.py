server = 'irc.chat.twitch.tv'
port = 6667
nickname = 'testing'
token = 'oauth:43rip6j6fgio8n5xly1oum1lph8ikl1' # https://twitchapps.com/tmi/
user = 'ardha27' # Your Twitch username
channel = '#grapplr' # The channel you want to retrieve messages from